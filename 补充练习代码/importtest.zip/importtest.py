# 导入 mydir 文件夹中  mytest1 这个模块，并给个别名为 mm
import mydir.mytest1 as mm


# 调用 mytest1 中的 mianji 函数
# a = mydir.mytest1.mianji(6)
a = mm.zhouchang(2, 3)
print(a)


# # 只导入 mytest1 模块中的 mianji 函数
# from mydir.mytest1 import mianji
#
# # 由于my导入 zhouchang 函数 ，在调用时会提示 zhouchang 没有定义的错误。
# b = zhouchang(2, 3)
# a = mianji(4)
# print(4)
