PI = 3.1415


def mianji(r):
    s = 0
    s = r * r * PI
    return s


def zhouchang(a, b):
    z = 0
    z = (a + b) * 2
    return z


# c = mianji(3)
# print(format("面积：%.2f (平方米)" % c))

# 相当于以下部分是对本文件（模块）进行测试的代码
if __name__ == '__main__':
    c = mianji(3)
    print(format("面积：%.2f (平方米)" % c))
