# 导入同级目录下的 mytest1 模块
import mytest1

a = mytest1.mianji(5)
print(a)
